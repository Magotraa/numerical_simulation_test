// SingleNeuron.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <algorithm>
using namespace std;




class Neuron  //one neuron -single layer
{  
public:
	float w_, b_;
	float x_temp;
	float alpha_ =  1e-5;


	Neuron();
	~Neuron();
	float proForward(const float& x);
	float getActIdentity(const float& x);
	float getActrelu(const float& x);
	float getGradActIdentity();


	void propBackward(const float& dEdy);
	

private:

};

float Neuron::getActIdentity(const float& x)
{
	return x;
}

float Neuron::getActrelu(const float& x)
{
	return   max(0.0f,x);
}


float Neuron::proForward(const float& x)
{	
	x_temp = x;
	//affine sum
	const float& sum = w_ * x + b_;
	//activation
	return getActIdentity(sum);
	//return getActrelu(sum);
}	


float Neuron::getGradActIdentity()
{
	return 1;

}

void Neuron::propBackward(const float& dEdy)
{
	const float 	dEdw = dEdy * getGradActIdentity() *  x_temp;
	const float 	dEdb = dEdy * getGradActIdentity() *  1.0;

	w_  -= alpha_ * dEdw;
	b_  -= alpha_ * dEdb;

}


Neuron::Neuron()
{

	//Neuron::w_ = 2.0;
	//Neuron::b_ = 1.0;
	w_ = 2.0; 
	b_ = 1.0;

	
}

Neuron::~Neuron()
{
}

int main()
{ 


	Neuron my_neuron;
	float x_input;
	cout << "enter input"<<endl;
	cin >> x_input;
	const float y = my_neuron.proForward(x_input);

	cout << "y_out before training " << y << endl;

	float y_targret;
	cout << "enter y target"<< endl;
	cin >> y_targret;

	while (true)
	{

		const float y = my_neuron.proForward(x_input);
		const float error = y_targret - y;
		const float E = 0.5 * error * error;


		cout << "squared error = " << E << endl;
		if (E < 1e-3) break;

		const float dEdy = y - y_targret; //-error
		my_neuron.propBackward(dEdy); //update w and b in this function

	}


	const float y_after_training = my_neuron.proForward(x_input);

	cout << "y_out y_after_training training " << y_after_training  << endl;


	//cout << "Hello neuron" << endl;
	
	/*cout << my_neuron.proForward(-1.0f) << endl;
	cout << my_neuron.proForward(0.0) << endl;
	cout << my_neuron.proForward(0.5) << endl;
	cout << my_neuron.proForward(1.0) << endl;*/
	
	
	return 0;
}

