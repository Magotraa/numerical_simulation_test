#include"stdafx.h"
#include<iostream>

using namespace std;




class Neuron
{
protected:

	float w_;  // weight 
	float b_; // bias
	float learning_rate; // learning rate alpha


public:



	Neuron();
	~Neuron();

	float getRandReal(const float& min, const float& max)
	{

		return rand() / (float)RAND_MAX * (max - min) + min;
	}


	float getSigma(const float& x_input)
	{
		return w_* x_input + b_;

	}

	float getSigmoid(const float& x)
	{
		return  1.0 / (1.0 + exp(-x));

	}
	float proForward(const float& x_input)
	{

		return getSigma(x_input);
	}

	float getGradientSigmoid(const float& x)
	{
		const float temp = getSigmoid(x);
			return temp * (1 - temp);
	}



	void proBackwardFromGradient(const float& x_input, const float& dloss_dy, const float& learning_rate)
	{
		
		const float	dy_dsigma = getGradientSigmoid(getSigma(x_input));
		const float dsigma_dw = x_input;
		const float dsigma_db = 1;

		const float dse_dw = dloss_dy * dy_dsigma * dsigma_dw;
		const float dse_db = dloss_dy * dy_dsigma * dsigma_db;



		//updating both coefficients simultaneouly

		w_ -= dse_dw  * learning_rate;
		b_ -= dse_db  * learning_rate;


	}


	void proBackpropagation(const float& x_input, const float& y_target, const float& learning_rate )
	{
		const float y_output = proForward(x_input);
		const float error = y_target - y_output;
		const float se = 0.5 * error * error;
		const float dse_dy = (y_target - y_output)  * -1;
		
		proBackwardFromGradient(x_input,dse_dy,learning_rate);

	}

private:

};

Neuron::Neuron()
{    //uniform random intialization
	w_ = getRandReal(-1e-3, 1e-3);
	b_ = getRandReal(-1e-3, 1e-3);
}

Neuron::~Neuron()
{
}

int main()
{

	Neuron single_neuron;

	cout <<"Single neuron forward pass       "<<" input: 1.0     " << "    Y output is as:"<<single_neuron.proForward(1.0) << endl;

	float x , y ;
	float alpha = 1e-3;
	cin >> x;
	cin >> y;


	for (int i = 0; i < 1000000000; ++i)
	{
		if (i%10000 ==0)
		cout << "Single neuron forward pass       " << " input:      "<< x << "    Y output is as:" << single_neuron.proForward(0.0) << endl;

		single_neuron.proBackpropagation(x, y, alpha);

	}

	return 0;
}